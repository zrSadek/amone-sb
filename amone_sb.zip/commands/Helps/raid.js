const Discord = require("discord.js-selfbot-v13");
const {  language } = require("../../fonctions")

module.exports = {
  name: "raid",
  description: "Menu Help",
  run: async (client, message, args, db, prefix) => {

    message.edit(await language(client, `
♫︎ __**Amone**__ ♫︎
*Vaut mieux être seul que mal accompagné.*
\`${prefix}banall\` ➜ **ban  all un serveur**
\`${prefix}delc\` ➜ **Delete tout les salons du serveur**
\`${prefix}spam\` ➜ **Spam un message**`
,`♫︎ __**Ntwork**__ ♫︎
*Better to be alone than in bad company.*
\`${prefix}banall\` ➜ **ban all a server**
\`${prefix}delc\` ➜ **Delete all channels from server**
\`${prefix}spam\` ➜ **Spam message**`))
  }
}; 